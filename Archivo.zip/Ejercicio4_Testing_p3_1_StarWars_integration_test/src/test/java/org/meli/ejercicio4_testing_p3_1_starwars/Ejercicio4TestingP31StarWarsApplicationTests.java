package org.meli.ejercicio4_testing_p3_1_starwars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio4TestingP31StarWarsApplicationTests {

    @Test
    void contextLoads() {
    }

}
