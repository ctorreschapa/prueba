package org.meli.ejercicio4_testing_p3_1_starwars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio4TestingP31StarWarsApplication {

    public static void main(String[] args) {
        SpringApplication.run(Ejercicio4TestingP31StarWarsApplication.class, args);
    }

}
