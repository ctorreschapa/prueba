package org.meli.obtenerdiploma.exception;

public class NotAcceptable extends RuntimeException {

    public NotAcceptable(String message) {
        super(message);
    }
}