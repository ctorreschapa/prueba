package org.meli.ejercicio4_testing_p5_1_calculadorametroscuadrados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio4TestingP51CalculadoraMetrosCuadradosApplication {

    public static void main(String[] args) {
        SpringApplication.run(Ejercicio4TestingP51CalculadoraMetrosCuadradosApplication.class, args);
    }

}
