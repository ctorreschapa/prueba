package org.meli.ejercicio4_testing_p5_1_calculadorametroscuadrados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio4TestingP51CalculadoraMetrosCuadradosApplicationTests {

    @Test
    void contextLoads() {
    }

}
